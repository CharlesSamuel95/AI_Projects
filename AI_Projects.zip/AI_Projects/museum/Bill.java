import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Does nothing meaningful
 * 
 * 
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Bill extends Actor
{
    /**
     * Act - do whatever the Bill wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        // Add your action code here.
    }    
    
    
}
